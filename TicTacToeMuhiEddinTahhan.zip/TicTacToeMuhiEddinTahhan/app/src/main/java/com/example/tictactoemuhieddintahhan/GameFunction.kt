package com.example.tictactoemuhieddintahhan

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class GameFunction : AppCompatActivity() {
    private var playerPlaying = 1
    private var pOne = arrayListOf<Int>()
    private var pTwo = arrayListOf<Int>()
    var winner = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_function)
        var button = findViewById<Button>(R.id.button10) //variable to control the reset button
        button.setOnClickListener {
            buttonActivator()       //calling the function to activate the buttons after rest
            textReset()             // calling function to start the buttons with empty texts
            colorRset()             // calling a function to put back the color to the defult color
            winner = 0              // reseting the winner variable to zero so it can take a value of 1 or 2 (x wins or o)
            pOne.clear()            // clearing the array of player one
            pTwo.clear()            // clearing the array of player two
        }
    }
    fun buttonClicked(view: View) {         // function to determain what happens when a button is being clicked
        val buttonClicked = view as Button
        var buttonId = 0

        when (buttonClicked.id) {           // giving each button an integer "did that because it is easier than dealing with arrays :)
            R.id.button1 -> buttonId = 11   // first is number of rows, second is number of coulmns
            R.id.button2 -> buttonId = 12   // these ID's are gonna be put in the array of the player that presses on the button
            R.id.button3 -> buttonId = 13   // it will be useful to determain the winner
            R.id.button4 -> buttonId = 21
            R.id.button5 -> buttonId = 22
            R.id.button6 -> buttonId = 23
            R.id.button7 -> buttonId = 31
            R.id.button8 -> buttonId = 32
            R.id.button9 -> buttonId = 33
        }
        if (playerPlaying == 1) {          // assigned player 1 with X and to change to player 2
            buttonClicked.text = "X"       // and give the cell that has been clicked in the array of pOne
            buttonClicked.setBackgroundResource(R.color.X)
            pOne.add(buttonId)
            playerPlaying = 2
        } else {
            buttonClicked.text = "O"       // same as the function above but the opposite way
            buttonClicked.setBackgroundResource(R.color.O)
            pTwo.add(buttonId)
            playerPlaying = 1
        }
        buttonClicked.isEnabled = false     // after every click, deactivate the button
        winChecker()        // calling a function that has the condition to win
    }

    private fun winChecker() {
        if (pOne.contains(11) && pOne.contains(12) && pOne.contains(13) ||
            pOne.contains(21) && pOne.contains(22) && pOne.contains(23) ||
            pOne.contains(31) && pOne.contains(32) && pOne.contains(33) ||
            pOne.contains(11) && pOne.contains(21) && pOne.contains(31) ||
            pOne.contains(12) && pOne.contains(22) && pOne.contains(32) ||
            pOne.contains(13) && pOne.contains(23) && pOne.contains(33) ||
            pOne.contains(11) && pOne.contains(22) && pOne.contains(33) ||
            pOne.contains(13) && pOne.contains(22) && pOne.contains(31)
        ) {
            winner = 1  // there are limitid sequances that can a player win by it
        }               // all the sequances where put in an if statement to check if X wins

        if (pTwo.contains(11) && pTwo.contains(12) && pTwo.contains(13) ||
            pTwo.contains(21) && pTwo.contains(22) && pTwo.contains(23) ||
            pTwo.contains(31) && pTwo.contains(32) && pTwo.contains(33) ||
            pTwo.contains(11) && pTwo.contains(21) && pTwo.contains(31) ||
            pTwo.contains(12) && pTwo.contains(22) && pTwo.contains(32) ||
            pTwo.contains(13) && pTwo.contains(23) && pTwo.contains(33) ||
            pTwo.contains(11) && pTwo.contains(22) && pTwo.contains(33) ||
            pTwo.contains(13) && pTwo.contains(22) && pTwo.contains(31)
        ) {
            winner = 2      // same as above but for O
        }
        if (winner == 1) {
            Toast.makeText(this, "Player X is the winner", Toast.LENGTH_LONG).show()
            buttonDeactivator()     //put a massage when X wins and deactivat the buttons

        } else if (winner == 2) {
            Toast.makeText(this, "Player O is the winner", Toast.LENGTH_LONG).show()
            buttonDeactivator()     // same for O
        }
    }
    private fun buttonDeactivator() {       //function that deactivate the buttons
        findViewById<Button>(R.id.button1).isEnabled = false    //boolean expression made to false
        findViewById<Button>(R.id.button2).isEnabled = false
        findViewById<Button>(R.id.button3).isEnabled = false
        findViewById<Button>(R.id.button4).isEnabled = false
        findViewById<Button>(R.id.button5).isEnabled = false
        findViewById<Button>(R.id.button6).isEnabled = false
        findViewById<Button>(R.id.button7).isEnabled = false
        findViewById<Button>(R.id.button8).isEnabled = false
        findViewById<Button>(R.id.button9).isEnabled = false
    }
    private fun buttonActivator() {
        findViewById<Button>(R.id.button1).isEnabled = true // opposite of the previous function
        findViewById<Button>(R.id.button2).isEnabled = true
        findViewById<Button>(R.id.button3).isEnabled = true
        findViewById<Button>(R.id.button4).isEnabled = true
        findViewById<Button>(R.id.button5).isEnabled = true
        findViewById<Button>(R.id.button6).isEnabled = true
        findViewById<Button>(R.id.button7).isEnabled = true
        findViewById<Button>(R.id.button8).isEnabled = true
        findViewById<Button>(R.id.button9).isEnabled = true
    }
    private fun textReset() {
        findViewById<Button>(R.id.button1).text = ""    //reset all the board to empty cell
        findViewById<Button>(R.id.button2).text = ""    //text wise
        findViewById<Button>(R.id.button3).text = ""
        findViewById<Button>(R.id.button4).text = ""
        findViewById<Button>(R.id.button5).text = ""
        findViewById<Button>(R.id.button6).text = ""
        findViewById<Button>(R.id.button7).text = ""
        findViewById<Button>(R.id.button8).text = ""
        findViewById<Button>(R.id.button9).text = ""
    }
    private fun colorRset() { //to reset the color of the cells to the original color
        findViewById<Button>(R.id.button1).setBackgroundResource(R.color.Default)
        findViewById<Button>(R.id.button2).setBackgroundResource(R.color.Default)
        findViewById<Button>(R.id.button3).setBackgroundResource(R.color.Default)
        findViewById<Button>(R.id.button4).setBackgroundResource(R.color.Default)
        findViewById<Button>(R.id.button5).setBackgroundResource(R.color.Default)
        findViewById<Button>(R.id.button6).setBackgroundResource(R.color.Default)
        findViewById<Button>(R.id.button7).setBackgroundResource(R.color.Default)
        findViewById<Button>(R.id.button8).setBackgroundResource(R.color.Default)
        findViewById<Button>(R.id.button9).setBackgroundResource(R.color.Default)
    }
}